<?php
    
    /*
    $MySql_server = "localhost";
    $MySql_user ="root";
    $MySql_pass = "";
    $MySql_db = "coaching";

    $base_url = "http://localhost/";
    */

    $MySql_server = "localhost";
    $MySql_user ="wave123";
    $MySql_pass = "wave123";
    $MySql_db = "wavecarrier";

    $base_url = "http://wavecarrierinstitute.com/";

?>