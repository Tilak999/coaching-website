<nav class="fh5co-nav" role="navigation">
    <div class="top-menu">
        <div class="container">
            <div class="row">
               <div class="col-md-4 col-sm-2 col-xs-10">
                    <div id="fh5co-logo">
                        <img src="/images/header.png">
                    </div>
                </div>
                <div class="col-xs-8 col-sm-10 col-sm-8 text-right menu-1">
                    <ul>
                        <li><a class="nav-btn" href="/index.php">Home</a></li>
                        <li><a class="nav-btn" href="/student/dashboard.php">Dashboard</a></li>
                        <li><a class="nav-btn" href="/acheivers.php">Acheivers</a></li>
                        <li><a class="nav-btn" href="/about.php">About</a></li>
                        <li><a class="nav-btn" href="/contact.php">Contact</a></li>
                        <li class="btn-cta"><a href="/logout.php"><span>Logout</span></a></li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</nav>