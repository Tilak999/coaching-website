<nav class="fh5co-nav" role="navigation">
    <div class="top-menu">
        <div class="container">
            <div class="row">
                 <div class="col-md-4 col-sm-3 col-xs-6">
                    <div id="fh5co-logo">
                        <img src="/images/header.png" width="100%">
                    </div>
                </div>
                <div class="col-md-8 col-sm-12 col-xs-6 text-right menu-1">
                    <ul>
                        <li><a class="nav-btn" href="/index.php">Home</a></li>
                        <li><a class="nav-btn" href="/login.php">Take Quiz</a></li>
                        <li><a class="nav-btn" href="/acheivers.php">Acheivers</a></li>
                        <li><a class="nav-btn" href="/about.php">About</a></li>
                        <li><a class="nav-btn" href="/contact.php">Contact</a></li>
                        <li class="btn-cta"><a href="/login.php"><span>Login</span></a></li>
                        <li class="btn-cta"><a href="/register.php"><span>Sign Up</span></a></li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</nav>