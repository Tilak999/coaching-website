<footer id="fh5co-footer" role="contentinfo">
    <div class="container">
        <div class="row row-pb-md">
            <div class="col-md-3 fh5co-widget">
                <h4>About us</h4>
                <p>Online portal play a very important role in the field of education it consist less time and work for the student. We are providing the best study material and online test series throughout India in which in one academic year student will get 150 mock test.</p>
            </div>
            <div class="col-md-3 col-md-push-1">
                <h4>Navigation</h4>
                <ul class="fh5co-footer-links">
                    <li><a href="/index.php">Home</a></li>
                    <li><a href="/about_quiz.php">Take Quiz</a></li>
                    <li><a href="/about.php#fh5co-experts">Expert Faculty</a></li>
                    <li><a href="/about.php">About us</a></li>
                    <li><a href="/contact.php">Contact us</a></li>
                </ul>
            </div>

            <div class="col-md-3 col-md-push-1">
                <h4>Contact Information</h4>
                <ul class="fh5co-footer-links">
                    <li>H.O. ADDRESS</li>
					<li>460 ASHWATH NAGAR</li>
                    <li>THANISANDRA MAIN ROAD</li> 
                    <li>BANGALORE-560077</li>
                    <li><a href="tel://1234567920">+ 1235 2355 98</a></li>
                    <li><a href="mailto:info@wavecarrierinstitute.com">info@wavecarrierinstitute.com</a></li>
                    <li><a href="http://wavecarrierinstitute.com">wavecarrierinstitute.com</a></li>
                    <li><a href="https://www.facebook.com/wavecarrierinstitute/"><i class="icon-facebook"></i> wavecarrierinstitute</a></li>
                </ul>
            </div>

            <div class="col-md-3 col-md-push-1">
                <h4>Opening Hours</h4>
                <ul class="fh5co-footer-links">
                    <li>Mon - Sat: 9:00 - 21 00</li>
                </ul>
            </div>

        </div>

        <div class="row copyright">
            <div class="col-md-12 text-center">
                <p>
                    <small class="block">&copy; Wave Carrier Institute. All Rights Reserved.</small> 
                    <small class="block">Designed by <a href="http://hunarsfox.com/" target="_blank">HunarsFox.com</a></small>
                </p>
                <p>
                    <ul class="fh5co-social-icons">
                        <li><a href="#"><i class="icon-twitter"></i></a></li>
                        <li><a href="https://www.facebook.com/wavecarrierinstitute/"><i class="icon-facebook"></i></a></li>
                    </ul>
                </p>
            </div>
        </div>

    </div>
</footer>